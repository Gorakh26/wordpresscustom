

    <!-- Start Footer Area -->
    <section class="footer-section pt-100 pb-70">
        <div class="container">
            <div class="subscribe-area">
                <div class="row align-items-center">
                    <div class="col-lg-6 col-md-6">
                        <div class="subscribe-content">
                            <h2>Join Our Newsletter</h2>
                            <p>News letter dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt.</p>
                        </div>
                    </div>

                    <div class="col-lg-6 col-md-6">
                        <form class="newsletter-form">
                            <input type="email" class="input-newsletter" placeholder="Enter your email" name="EMAIL" required autocomplete="off">
                            <button type="submit">
                                    Subscribe Now
                                </button>

                            <div id="validator-newsletter" class="form-result"></div>
                        </form>
                    </div>
                </div>
            </div>

            <div class="row">
                <div class="col-lg-3 col-md-6 col-sm-6">
                    <div class="single-footer-widget">
                        <div class="footer-heading">
                            <h3>About Us</h3>
                        </div>
                        <p><?php echo of_get_option('f-about-text');?></p>
                        <ul class="footer-social">
                            <li>
                                <a href="<?php echo of_get_option('facebook');?>">
                                    <i class="flaticon-facebook"></i>
                                </a>
                            </li>

                            <li>
                                <a href="<?php echo of_get_option('twitter');?>">
                                    <i class="flaticon-twitter"></i>
                                </a>
                            </li>

                            <li>
                                <a href="<?php echo of_get_option('pinterest');?>">
                                    <i class="flaticon-pinterest"></i>
                                </a>
                            </li>

                            <li>
                                <a href="<?php echo of_get_option('instagram');?>">
                                    <i class="flaticon-instagram"></i>
                                </a>
                            </li>
                        </ul>
                    </div>
                </div>

                <div class="col-lg-3 col-md-6 col-sm-6">
                    <div class="single-footer-widget">
                        <div class="footer-heading">
                            <h3>Important Links</h3>
                        </div>

                        <ul class="footer-quick-links">
                            <li>
                                <a href="about.html">About Us</a>
                            </li>
                            <li>
                                <a href="projects-1.html">Project</a>
                            </li>
                            <li>
                                <a href="services-1.html">Services</a>
                            </li>
                            <li>
                                <a href="blog-1.html">Blog</a>
                            </li>
                            <li>
                                <a href="contact.html">Contact</a>
                            </li>
                        </ul>
                    </div>
                </div>

                <div class="col-lg-3 col-md-6 col-sm-6">
                    <div class="single-footer-widget">
                        <div class="footer-heading">
                            <h3>Featured Service</h3>
                        </div>
                        <ul class="footer-quick-links">
                            <li>
                                <a href="#">IT Management</a>
                            </li>
                            <li>
                                <a href="#">Development</a>
                            </li>
                            <li>
                                <a href="services-1.html">Services</a>
                            </li>
                            <li>
                                <a href="#">UI/UX Design</a>
                            </li>
                            <li>
                                <a href="#">Support Engineer</a>
                            </li>
                        </ul>
                    </div>
                </div>

                <div class="col-lg-3 col-md-6 col-sm-6">
                    <div class="single-footer-widget">
                        <div class="footer-heading">
                            <h3>Contact</h3>
                        </div>

                        <div class="footer-info-contact">
                            <i class="flaticon-phone-call"></i>
                            <h3>Phone</h3>
                            <span><a href="tel:<?php echo of_get_option('phone-number');?>"><?php echo of_get_option('phone-number');?></a></span>
                        </div>

                        <div class="footer-info-contact">
                            <i class="flaticon-envelope"></i>
                            <h3>Email</h3>
                            <span><a href="mailto:<?php echo of_get_option('email');?>"><span class="__cf_email__" data-cfemail="e8808d848487a88e9a8189c68b8785"><?php echo of_get_option('email');?></span></a>
                            </span>
                        </div>

                        <div class="footer-info-contact">
                            <i class="flaticon-pin"></i>
                            <h3>Address</h3>
                            <span><?php echo of_get_option('address');?></span>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!-- End Footer Area -->

    <!-- Start Copy Right Area -->
    <div class="copyright-area">
        <div class="container">
            <div class="copyright-area-content">
                <div class="row align-items-center">
                    <div class="col-lg-6 col-md-6">
                        <p>
                            <?php echo of_get_option('copyright');?> All Rights Reserved by
                            <a href="<?php echo of_get_option('reservedurl');?>" target="_blank">
                                    <?php echo of_get_option('reservedby');?>
                                </a>
                        </p>
                    </div>

                    <div class="col-lg-6 col-md-6">
                        <ul>
                            <li>
                                <a href="<?php bloginfo('template_url'); ?>/terms-conditions">Terms & Conditions</a>
                            </li>
                            <li>
                                <a href="<?php bloginfo('template_url'); ?>/privacy-policy">Privacy Policy</a>
                            </li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- End Copy Right Area -->
 <?php echo //do_shortcode('[contact-form-7 id="4726" title="Subscription"]'); ?>
    <!-- Start Go Top Section -->
    <div class="go-top">
        <i class="bx bx-chevron-up"></i>
        <i class="bx bx-chevron-up"></i>
    </div>
    <!-- End Go Top Section -->

    
    <script src="<?php bloginfo('template_url'); ?>/assets/js/jquery.min.js"></script>
    <script src="<?php bloginfo('template_url'); ?>/assets/js/popper.min.js"></script>
    <script src="<?php bloginfo('template_url'); ?>/assets/js/bootstrap.min.js"></script>
    <script src="<?php bloginfo('template_url'); ?>/assets/js/jquery.meanmenu.js"></script>
    <script src="<?php bloginfo('template_url'); ?>/assets/js/owl.carousel.js"></script>
    <script src="<?php bloginfo('template_url'); ?>/assets/js/jquery.magnific-popup.min.js"></script>
    <script src="<?php bloginfo('template_url'); ?>/assets/js/jquery.appear.min.js"></script>
    <script src="<?php bloginfo('template_url'); ?>/assets/js/odometer.min.js"></script>
    <script src="<?php bloginfo('template_url'); ?>/assets/js/jquery.ajaxchimp.min.js"></script>
    <script src="<?php bloginfo('template_url'); ?>/assets/js/form-validator.min.js"></script>
    <script src="<?php bloginfo('template_url'); ?>/assets/js/contact-form-script.js"></script>
    <script src="<?php bloginfo('template_url'); ?>/assets/js/wow.min.js"></script>
    <script src="<?php bloginfo('template_url'); ?>/assets/js/main.js"></script>
    <?php wp_footer(); ?>
</body>

</html>
<?php 

register_nav_menus( array(
		'header' =>'Top Nav Menu',
		'footer' =>'Footer Nav Menu'
	) );
	function add_additional_class_on_li($classes, $item, $args) {
	if(isset($args->add_li_class)) {
		$classes[] = $args->add_li_class;
	}
	return $classes;
}
add_filter('nav_menu_css_class', 'add_additional_class_on_li', 1, 3);

add_theme_support( 'custom-logo' ); 
function themename_custom_logo_setup() {
 $defaults = array(
 'height'      => 100,
 'width'       => 400,
 'flex-height' => true,
 'flex-width'  => true,
 'header-text' => array( 'site-title', 'site-description' ),
 );
 add_theme_support( 'custom-logo', $defaults );
}
add_action( 'after_setup_theme', 'themename_custom_logo_setup' );


function pds_widgets_init() {
	register_sidebar( array(
		'name'          => esc_html__( 'Sidebar', 'Fria' ),
		'id'            => 'sidebar-1',
	) );	
	register_sidebar( array(
		'name'          => esc_html__( 'Page Sidebar', 'Fria' ),
		'id'            => 'page-sidebar',
		
	) );	
	register_sidebar( array(
		'name'          => esc_html__( 'Footer One', 'Fria' ),
		'id'            => 'footer-one',
		
	) );
	register_sidebar( array(
		'name'          => esc_html__( 'Footer Two', 'Fria' ),
		'id'            => 'footer-two',
		
	) );
	register_sidebar( array(
		'name'          => esc_html__( 'Footer Three', 'Fria' ),
		'id'            => 'footer-three',
		
	) );
	
	register_sidebar( array(
		'name'          => esc_html__( 'Footer Four', 'pds' ),
		'id'            => 'footer-four',
		
	) );

}
add_action( 'widgets_init', 'pds_widgets_init' );

add_action('wp_enqueue_scripts', 'enqueue_script_jquery');
function enqueue_script_jquery() {
    wp_enqueue_script('jquery');
}

/* Function which displays your post date in time ago format */
function meks_time_ago() {
    return human_time_diff( get_the_time( 'U' ), current_time( 'timestamp' ) ).' '.__( 'ago' );
}



/*Custom Post type end*/
<!doctype html>
<html lang="zxx" class="theme-light">
<head>
    <meta charset="utf-8">
    <title><?php wp_title(); ?></title>
    <?php wp_head(); ?>
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <link rel="stylesheet" href="<?php bloginfo('template_url'); ?>/assets/css/bootstrap.min.css">
    <link rel="stylesheet" href="<?php bloginfo('template_url'); ?>/assets/css/owl.default.min.css">
    <link rel="stylesheet" href="<?php bloginfo('template_url'); ?>/assets/css/owl.carousel.min.css">
    <link rel="stylesheet" href="<?php bloginfo('template_url'); ?>/assets/css/magnific-popup.min.css">
    <link rel="stylesheet" href="<?php bloginfo('template_url'); ?>/assets/css/animate.min.css">
    <link rel="stylesheet" href="<?php bloginfo('template_url'); ?>/assets/css/boxicons.min.css">
    <link rel="stylesheet" href="<?php bloginfo('template_url'); ?>/assets/css/flaticon.css">
    <link rel="stylesheet" href="<?php bloginfo('template_url'); ?>/assets/css/meanmenu.css">
    <link rel="stylesheet" href="<?php bloginfo('template_url'); ?>/assets/css/odometer.min.css">
    <link rel="stylesheet" href="<?php bloginfo('template_url'); ?>/assets/css/style.css">
    <link rel="stylesheet" href="<?php bloginfo('template_url'); ?>/assets/css/dark.css">
    <link rel="stylesheet" href="<?php bloginfo('template_url'); ?>/assets/css/responsive.css">
    <link rel="icon" type="image/png" href="<?php bloginfo('template_url'); ?>/assets/img/favicon.png">
</head>

<body>

    <!-- Start Navbar Area -->
    <div class="navbar-area navbar-two">
        <div class="fria-responsive-nav">
            <div class="container">
                <div class="fria-responsive-menu">
                    <div class="logo">
                        <?php the_custom_logo(); ?>
                    </div>
                </div>
            </div>
        </div>

        <div class="fria-nav">
            <div class="container">
                <nav class="navbar navbar-expand-md navbar-light">
                    <div class="navbar-brand" >
                       <?php the_custom_logo(); ?>
                    </div>

                    <div class="collapse navbar-collapse mean-menu" id="navbarSupportedContent">
                        <?php wp_nav_menu( array( 'menu_class' => 'navbar-nav', 'menu_id' => '', 'container'   => '' , 'theme_location' => 'header','add_li_class'  => 'nav-item' ) ); ?>
                        

                        <div class="others-options">
                            <div class="option-item"><i class="search-btn flaticon-search"></i>
                                <i class="close-btn flaticon-cancel"></i>
                                <div class="search-overlay search-popup">
                                    <div class='search-box'>
                                        <form class="search-form">
                                            <input class="search-input" name="search" placeholder="Search" type="text">

                                            <button class="search-button" type="submit">
                                                    <i class="flaticon-search"></i>
                                                </button>
                                        </form>
                                    </div>
                                </div>
                            </div>

                            <a href="sign-up.html" class="default-btn">Sign In</a>
                        </div>
                    </div>
                </nav>
            </div>
        </div>
    </div>
    <!-- End Navbar Area -->

  
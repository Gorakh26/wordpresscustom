=== Icons Font Loader ===
Tags: webfont, flaticon, icons, font, flaticon
Contributors: abuhayat, shehabulislam
Requires at least: 3.0.1
Tested up to: 6.1.1
Stable tag: 1.1.2.1
Requires PHP: 7.1
Donate link: https://www.buymeacoffee.com/abuhayat
License: GPLv3 or later
License URI: http://www.gnu.org/licenses/gpl-3.0.html

Load Various Web Fonts/Icon Fonts (Flat Icon) To Your WordPress

== Description ==

Load Various Web Fonts/Icon Fonts (Flat Icon) To Your WordPress website


== Changelog ==

= 1.0 =
* Initial Release
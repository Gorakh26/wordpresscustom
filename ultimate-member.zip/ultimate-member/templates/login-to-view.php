<?php if ( ! defined( 'ABSPATH' ) ) exit; ?>

<div class="um-locked-content">

	<div class="um-locked-content-msg"><?php echo htmlspecialchars_decode( $lock_text ); ?></div>

</div>